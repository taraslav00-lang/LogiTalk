import threading
import base64
from socket import socket, AF_INET, SOCK_STREAM
from customtkinter import *
from tkinter import filedialog
from PIL import Image

class MainWindow(CTk):
    def __init__(self):
        super().__init__()
        self.geometry("400x300")
        self.title = "Chat client"
        self.username = "Artem"

        self.label = None
        self.menu_frame = CTkFrame(self, width=30, height=300)
        self.menu_frame.pack_propagate(False)
        self.menu_frame.place(x=0,y=0)
        self.is_show_menu = False
        self.speed_animate_menu = -20

        self.btn = CTkButton(self, text='>', command=self.toggle_show_menu, width=30)

    def toggle_show_menu(self):
        pass

if __name__ == "__main__":
    win = MainWindow()
    win.mainloop()