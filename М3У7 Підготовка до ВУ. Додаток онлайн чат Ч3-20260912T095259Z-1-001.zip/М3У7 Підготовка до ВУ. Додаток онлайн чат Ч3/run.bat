@echo off
:: Check for administrative privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :adminTasks
) else (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:adminTasks
:: Change directory to the script's actual folder location
cd /d "%~dp0"

pip install customtkinter
pip install pillow
start "" python server.py
start "" python pro_ui.py
start "" python pro_ui.py